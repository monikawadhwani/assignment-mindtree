<?php
include_once 'config/database.php';
include_once 'router.php';

// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE");
header('WWW-Authenticate: Basic realm="cisco"');
  
// get database connection
$database = new DatabaseService();
$db = $database->getConnection();
  
$router = new router($db);
// get router id
$id = $_GET['id'];

// set router id to be deleted
$router->id = $id;
  
// delete the router
if($router->deleteRouter()){
  
    // set response code - 200 ok
    http_response_code(200);
  
    // tell the router
    echo json_encode(array("message" => "router was deleted."));
}
  
// if unable to delete the router
else{
  
    // set response code - 503 service unavailable
    http_response_code(503);
  
    // tell the router
    echo json_encode(array("message" => "Unable to delete router."));
}
?>