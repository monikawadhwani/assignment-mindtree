<?php
include_once 'config/database.php';
include_once 'router.php';

// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header('WWW-Authenticate: Basic realm="cisco"');

// instantiate database and router object
$database = new DatabaseService();
$db = $database->getConnection();


/**Get api for router**/
$router = new router($db);	

// get id of router to be edited
$data = json_decode(file_get_contents("php://input"));	  
// set ID property of router to be edited
$router->id = $data->id;
  
// set router property values
$router->first_name = $data->first_name;
$router->last_name = $data->last_name;
$router->email = $data->email;
$router->password = md5($data->password);
  
// update the router
if($router->updateRouter()){
  
    // set response code - 200 ok
    http_response_code(200);
  
    // tell the router
    echo json_encode(array("message" => "router was updated."));
}
  
// if unable to update the router, tell the router
else{
  
    // set response code - 503 service unavailable
    http_response_code(503);
  
    // tell the router
    echo json_encode(array("message" => "Unable to update router."));
}


?>
