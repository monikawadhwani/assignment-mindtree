<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header('WWW-Authenticate: Basic realm="cisco"');

  
// get database connection
include_once 'config/database.php';
include_once 'router.php';
  
$database = new DatabaseService();
$db = $database->getConnection();
  
$router = new router($db);
  
// get posted data
$data = json_decode(file_get_contents("php://input"));
  
// make sure data is not empty
if(
    !empty($data->sapid) &&
    !empty($data->hostname) &&
    !empty($data->loopback) &&
    !empty($data->macadd)
){
  
    // set router property values
    $router->first_name = $data->first_name;
    $router->last_name = $data->last_name;
    $router->email = $data->email;
    $router->password = md5($data->password);    
  
    // create router
    if($router->createRouter()){
  
        // set response code - 201 created
        http_response_code(201);
  
        // tell the router
        echo json_encode(array("message" => "router was created."));
    }
  
    // if unable to create the router, tell the router
    else{
  
        // set response code - 503 service unavailable
        http_response_code(503);
  
        // tell the router
        echo json_encode(array("message" => "Unable to create router."));
    }
}
  
// tell the router data is incomplete
else{
  
    // set response code - 400 bad request
    http_response_code(400);
  
    // tell the router
    echo json_encode(array("message" => "Unable to create router. Data is incomplete."));
}
?>