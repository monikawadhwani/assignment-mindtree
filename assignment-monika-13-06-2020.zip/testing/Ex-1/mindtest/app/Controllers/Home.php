<?php namespace App\Controllers;
use App\Models\RouterModel;

class Home extends BaseController
{
	
	public function index()
	{		
		$data['dns'] = $this->getAllRouter();		
		echo view('manageRouter', $data);
	}	

	public function getAllRouter(){
		$db = \Config\Database::connect();
		$routerModel = new RouterModel($db);	
		$data = $routerModel->getRouterDetail();
		return $data;		
	}

	public function getRouter(){			
		$id = $this->request->uri->getSegment(2);
		$db = \Config\Database::connect();
		$routerModel = new RouterModel($db);		
		$data = $routerModel->getRouterDetail($id);		
		echo json_encode($data);
	
	}

	public function addRouter(){			
		$routerDetails = $_POST;
		$db = \Config\Database::connect();
		$routerModel = new RouterModel($db);		
		$res = $routerModel->saveRouter($routerDetails);
		if($res){
			$session = \Config\Services::session();
			$session->setFlashdata('item', 'Router added successfully');
			echo true; die;
		}
	}

	public function deleteRouter(){
		$id = $this->request->uri->getSegment(2);
		$db = \Config\Database::connect();
		$routerModel = new RouterModel($db);
		$routerModel->deleteRouter($id);
		echo 1;
	}

}
