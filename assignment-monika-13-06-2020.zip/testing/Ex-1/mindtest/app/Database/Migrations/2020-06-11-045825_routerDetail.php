<?php namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class RouterDetail extends Migration
{
	public function up()
	{
		$this->forge->addField([
						'id' =>[
							'type'  => 'INT',
							'unsigned'       => TRUE,
                            'auto_increment' => TRUE
						],
                        'sapid'          => [
                                'type'           => 'VARCHAR',
                                'constraint'     => '225', 
                        ],
                        'hostname'       => [
                                'type'           => 'VARCHAR',
                                'constraint'     => '225',
                        ],
                        'loopback' => [
                                'type'           => 'VARCHAR',
                                'constraint'     => '255',                                
                        ],
                        'macadd' => [
                                'type'           => 'VARCHAR',
                                'constraint'     => '255',                                
                        ],
                        'status' => [
                        	'type'  => 'INT',
							'unsigned'       => TRUE,                            
                        ],
                ]);
                $this->forge->addKey('id', TRUE);
                $this->forge->createTable('routerDetail');
	}

	//--------------------------------------------------------------------

	public function down()
	{
		$this->forge->dropTable('routerDetail');
	}
}
