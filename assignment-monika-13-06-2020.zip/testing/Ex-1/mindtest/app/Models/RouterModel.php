<?php namespace App\Models;

use \CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;

class RouterModel extends Model
{
    protected $db;

    public function __construct(ConnectionInterface &$db)
    {
            $this->db =& $db;

    }

    public function getRouterDetail($id=""){            
        $db = \Config\Database::connect();
        $builder = $db->table('routerDetail');        
        if($id!=""){
           $builder->where('id', $id);
            $query = $builder->get();
        
        }else{
            $query = $builder->get();
        }
        return $query->getResult();         
    }    

    public function saveRouter($routerDetail){        
        $primaryKey = 'id';

        // Does an insert()
        $data = [
               'sapid' => $routerDetail['sapid'],
                'hostname'    => $routerDetail['hostname'],
                'loopback' => $routerDetail['loopback'],
                'macadd' => $routerDetail['macadd'],
                'status' =>1
        ];

        $db = \Config\Database::connect();
        $builder = $db->table('routerDetail');
        if($routerDetail['id']!=''){
            $builder->where('id', $routerDetail['id']);
            $builder->update($data); 
        }else{
           $builder->insert($data);
        }
        return true;
    }   

    public function deleteRouter($id){   
        $db = \Config\Database::connect();    
        $builder = $db->table('routerDetail'); 
        $data = [
               'status' => 0
        ];
 
        $builder->where('id', $id);
        $builder->update($data);
        return true;
    }

}

?>